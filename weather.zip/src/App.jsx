import React from 'react'
import Wether from './Components/Wether'

const App = () => {
  return (
   <>

   <Wether/>
   </>
  )
}

export default App